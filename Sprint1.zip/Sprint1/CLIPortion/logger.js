// this will be the log function that generates the log files and adds them to the correct folder
// Perhaps have a log file for a few cases to seperate logs into more easily searchable files

// import and require statements will go here
const fs = require('fs');

// constants will go here, ie default values for files, error messages, etc.


// any sub functions unique to this file will go here


// the main function will go here
// unsure of exact parameters for this function at the moment
const logger = (...parameters) => {
    // the logger code will go here
    // rubric says  a specific format should be used. I can't find it, ask Pete if we all can't find it
}


// export the logger function and any other functions that need to be used outside this file
module.exports = {
    logger,
}