-- ALL APPOINTMENTS FOR A SPECIFIC DATE

SELECT appt_date, appt_id
FROM public."Appointments"
WHERE appt_date = '2021-09-09';