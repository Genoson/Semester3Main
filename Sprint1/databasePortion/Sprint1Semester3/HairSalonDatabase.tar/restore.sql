--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Hair Salon";
--
-- Name: Hair Salon; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Hair Salon" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "Hair Salon" OWNER TO postgres;

\connect -reuse-previous=on "dbname='Hair Salon'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Address" (
    address_id integer NOT NULL,
    house_num integer NOT NULL,
    street_name character varying(32) NOT NULL,
    postal_code character varying(6) NOT NULL,
    city character varying(16) NOT NULL
);


ALTER TABLE public."Address" OWNER TO postgres;

--
-- Name: Appointment Products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appointment Products" (
    appt_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer
);


ALTER TABLE public."Appointment Products" OWNER TO postgres;

--
-- Name: Appointment Services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appointment Services" (
    appt_id integer NOT NULL,
    service_id integer NOT NULL
);


ALTER TABLE public."Appointment Services" OWNER TO postgres;

--
-- Name: Appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appointments" (
    appt_id integer NOT NULL,
    customer_id integer NOT NULL,
    employee_id integer NOT NULL,
    appt_date date NOT NULL,
    appt_time time without time zone NOT NULL
);


ALTER TABLE public."Appointments" OWNER TO postgres;

--
-- Name: Certifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Certifications" (
    cert_id integer NOT NULL,
    cert_desc character varying(120) NOT NULL
);


ALTER TABLE public."Certifications" OWNER TO postgres;

--
-- Name: Customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Customer" (
    customer_id integer NOT NULL,
    first_name character varying(32) NOT NULL,
    last_name character varying(32) NOT NULL,
    phone_num numeric NOT NULL
);


ALTER TABLE public."Customer" OWNER TO postgres;

--
-- Name: Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee" (
    employee_id integer NOT NULL,
    first_name character varying(16),
    last_name character varying(32),
    phone_num numeric,
    pay_rate money
);


ALTER TABLE public."Employee" OWNER TO postgres;

--
-- Name: Employee Addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee Addresses" (
    employee_id integer NOT NULL,
    address_id integer NOT NULL
);


ALTER TABLE public."Employee Addresses" OWNER TO postgres;

--
-- Name: Employee Certifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee Certifications" (
    employee_id integer NOT NULL,
    cert_id integer NOT NULL
);


ALTER TABLE public."Employee Certifications" OWNER TO postgres;

--
-- Name: Invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Invoices" (
    invoice_id integer NOT NULL,
    appt_id integer NOT NULL,
    total_cost money NOT NULL
);


ALTER TABLE public."Invoices" OWNER TO postgres;

--
-- Name: Products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Products" (
    product_id integer NOT NULL,
    product_name character varying(32) NOT NULL,
    product_cost money NOT NULL,
    current_stock integer NOT NULL,
    num_sold integer NOT NULL,
    supplier_id integer NOT NULL
);


ALTER TABLE public."Products" OWNER TO postgres;

--
-- Name: Service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Service" (
    service_id integer NOT NULL,
    service_type character varying(64) NOT NULL,
    service_cost money NOT NULL
);


ALTER TABLE public."Service" OWNER TO postgres;

--
-- Name: Supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Supplier" (
    supplier_id integer NOT NULL,
    supplier_name character varying(32) NOT NULL,
    phone_num numeric NOT NULL,
    street_address character varying(64) NOT NULL,
    city character varying(32) NOT NULL,
    state character varying(32) NOT NULL,
    postal_code character varying(16)
);


ALTER TABLE public."Supplier" OWNER TO postgres;

--
-- Data for Name: Address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Address" (address_id, house_num, street_name, postal_code, city) FROM stdin;
\.
COPY public."Address" (address_id, house_num, street_name, postal_code, city) FROM '$$PATH$$/3654.dat';

--
-- Data for Name: Appointment Products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appointment Products" (appt_id, product_id, quantity) FROM stdin;
\.
COPY public."Appointment Products" (appt_id, product_id, quantity) FROM '$$PATH$$/3661.dat';

--
-- Data for Name: Appointment Services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appointment Services" (appt_id, service_id) FROM stdin;
\.
COPY public."Appointment Services" (appt_id, service_id) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: Appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appointments" (appt_id, customer_id, employee_id, appt_date, appt_time) FROM stdin;
\.
COPY public."Appointments" (appt_id, customer_id, employee_id, appt_date, appt_time) FROM '$$PATH$$/3659.dat';

--
-- Data for Name: Certifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Certifications" (cert_id, cert_desc) FROM stdin;
\.
COPY public."Certifications" (cert_id, cert_desc) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Customer" (customer_id, first_name, last_name, phone_num) FROM stdin;
\.
COPY public."Customer" (customer_id, first_name, last_name, phone_num) FROM '$$PATH$$/3650.dat';

--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee" (employee_id, first_name, last_name, phone_num, pay_rate) FROM stdin;
\.
COPY public."Employee" (employee_id, first_name, last_name, phone_num, pay_rate) FROM '$$PATH$$/3651.dat';

--
-- Data for Name: Employee Addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee Addresses" (employee_id, address_id) FROM stdin;
\.
COPY public."Employee Addresses" (employee_id, address_id) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: Employee Certifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee Certifications" (employee_id, cert_id) FROM stdin;
\.
COPY public."Employee Certifications" (employee_id, cert_id) FROM '$$PATH$$/3657.dat';

--
-- Data for Name: Invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Invoices" (invoice_id, appt_id, total_cost) FROM stdin;
\.
COPY public."Invoices" (invoice_id, appt_id, total_cost) FROM '$$PATH$$/3660.dat';

--
-- Data for Name: Products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Products" (product_id, product_name, product_cost, current_stock, num_sold, supplier_id) FROM stdin;
\.
COPY public."Products" (product_id, product_name, product_cost, current_stock, num_sold, supplier_id) FROM '$$PATH$$/3652.dat';

--
-- Data for Name: Service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Service" (service_id, service_type, service_cost) FROM stdin;
\.
COPY public."Service" (service_id, service_type, service_cost) FROM '$$PATH$$/3653.dat';

--
-- Data for Name: Supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Supplier" (supplier_id, supplier_name, phone_num, street_address, city, state, postal_code) FROM stdin;
\.
COPY public."Supplier" (supplier_id, supplier_name, phone_num, street_address, city, state, postal_code) FROM '$$PATH$$/3655.dat';

--
-- Name: Address Address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address"
    ADD CONSTRAINT "Address_pkey" PRIMARY KEY (address_id);


--
-- Name: Appointments Appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT "Appointments_pkey" PRIMARY KEY (appt_id);


--
-- Name: Certifications Certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certifications"
    ADD CONSTRAINT "Certifications_pkey" PRIMARY KEY (cert_id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (customer_id);


--
-- Name: Employee Addresses EMPLOYEE ADDRESSES_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee Addresses"
    ADD CONSTRAINT "EMPLOYEE ADDRESSES_pkey" PRIMARY KEY (employee_id, address_id);


--
-- Name: Employee Certifications Employee Certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee Certifications"
    ADD CONSTRAINT "Employee Certifications_pkey" PRIMARY KEY (employee_id, cert_id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (employee_id);


--
-- Name: Invoices Invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_pkey" PRIMARY KEY (invoice_id);


--
-- Name: Products Products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Products"
    ADD CONSTRAINT "Products_pkey" PRIMARY KEY (product_id);


--
-- Name: Service Service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_pkey" PRIMARY KEY (service_id);


--
-- Name: Supplier Supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Supplier"
    ADD CONSTRAINT "Supplier_pkey" PRIMARY KEY (supplier_id);


--
-- Name: Products Supplier_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Products"
    ADD CONSTRAINT "Supplier_fkey" FOREIGN KEY (supplier_id) REFERENCES public."Supplier"(supplier_id) NOT VALID;


--
-- Name: Employee Addresses address_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee Addresses"
    ADD CONSTRAINT address_fkey FOREIGN KEY (address_id) REFERENCES public."Address"(address_id);


--
-- Name: Invoices appointment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT appointment_fkey FOREIGN KEY (appt_id) REFERENCES public."Appointments"(appt_id);


--
-- Name: Appointment Products appointment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointment Products"
    ADD CONSTRAINT appointment_fkey FOREIGN KEY (appt_id) REFERENCES public."Appointments"(appt_id);


--
-- Name: Appointment Services appointment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointment Services"
    ADD CONSTRAINT appointment_fkey FOREIGN KEY (appt_id) REFERENCES public."Appointments"(appt_id);


--
-- Name: Employee Certifications cert_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee Certifications"
    ADD CONSTRAINT cert_fkey FOREIGN KEY (cert_id) REFERENCES public."Certifications"(cert_id);


--
-- Name: Appointments customer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT customer_fkey FOREIGN KEY (customer_id) REFERENCES public."Customer"(customer_id);


--
-- Name: Employee Certifications employee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee Certifications"
    ADD CONSTRAINT employee_fkey FOREIGN KEY (employee_id) REFERENCES public."Employee"(employee_id);


--
-- Name: Employee Addresses employee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee Addresses"
    ADD CONSTRAINT employee_fkey FOREIGN KEY (employee_id) REFERENCES public."Employee"(employee_id);


--
-- Name: Appointments employee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT employee_fkey FOREIGN KEY (customer_id) REFERENCES public."Customer"(customer_id);


--
-- Name: Appointment Products product_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointment Products"
    ADD CONSTRAINT product_fkey FOREIGN KEY (product_id) REFERENCES public."Products"(product_id);


--
-- Name: Appointment Services service_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointment Services"
    ADD CONSTRAINT service_fkey FOREIGN KEY (service_id) REFERENCES public."Service"(service_id);


--
-- PostgreSQL database dump complete
--

